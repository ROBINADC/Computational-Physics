#include "mpi.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include <ctime>


long double A=1;
long double Q=10000;//ȫ�ֲ���


void nextsol(long double* nextvec,long double* vec,long xdim,long tdim);//��һʱ���
int main(int argc, char *argv[])
{
	extern long double A,Q;
	long i,j;
	long tdim=1000000;//t���껮����Nt
	long xdim=50;//x���껮����Nx



	long double** sol=(long double**)calloc(tdim+1,sizeof(long double*));
	for(j=0;j<tdim+1;j++)
	{
		sol[j]=(long double*)calloc(xdim+1,sizeof(long double));
		for(i=0;i<xdim+1;i++)
			sol[j][i]=0;
	}

	for(i=1;i<xdim;i++)
		sol[0][i]=0.0;
	sol[0][0]=(4*sol[0][1]-sol[0][2])/3.0;
	sol[0][xdim]=0.0;//(4*sol[0][xdim-1]-sol[0][xdim-2]+2*Q)/3.0;
	//��ֵ

	for(j=1;j<tdim+1;j++)
		nextsol(sol[j],sol[j-1],xdim,tdim);
	//for(i=0;i<=xdim;i+=4)
	//{
	//	printf("\n{");
	//	for(j=0;j<=tdim+1;j+=20)
	//		printf("%lf,",sol[j][i]);
	//	printf("\b}\n");
	//}//��������
	printf("%lf",sol[tdim][xdim]);




	for(i=0;i<tdim+1;i++)
		free(sol[i]);
	free(sol);
	system("pause");
	return 0;

}
void nextsol(long double* nextvec,long double* vec,long xdim,long tdim)
{
	long i;
	nextvec[1]=vec[1]+2.0*(vec[2]-vec[1])*A*xdim*xdim/(3.0*tdim);
	nextvec[xdim-1]=vec[xdim-1]+2.0*(vec[xdim-2]+Q-vec[xdim-1])*A*xdim*xdim/(3.0*(long double)tdim);
	for(i=2;i<=xdim-2;i++)
		nextvec[i]=vec[i]+(vec[i-1]+vec[i+1]-2*vec[i])*A*xdim*xdim/(long double)tdim;
	nextvec[0]=(4*nextvec[1]-nextvec[2])/3.0;
	nextvec[xdim]=(4*nextvec[xdim-1]-nextvec[xdim-2]+2*Q)/3.0;
}