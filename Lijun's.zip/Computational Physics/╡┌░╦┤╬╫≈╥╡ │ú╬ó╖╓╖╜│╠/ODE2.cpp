#include "mpi.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include <ctime>

#define DIM 5

long double OMEGA=0.1;
long double AX=0.1;
long double AY=0.1;
long double T0=0.1;
long double T1=0.1;
long double T2=0.1;//ȫ�ֲ���

void diff(long double* diffvec,long double* vec);//΢�ַ�����
void stRK(long double* nextvec, long double* vec,int dim,long double h);//�Ľ�RK��
void varRK(long double* nextsol,long double* sol,int dim,long double* ph,long double epsln);//�䲽���Ľ�RK��
long double rangeerr(long double xmax,long double xmin,long double ymax,long double ymin);
void trypara(long double** sol,long double* perror1,int warmn,long double epsln,long double* ph,long double* pxmax,long double* pxmin,long double* pymax,long double* pymin);
int main(int argc, char *argv[])
{
	extern long double OMEGA,AX,AY,T0,T1,T2;//����������
	int i,j;
	long tsize=10000;//ʱ���������޷�Χ
	long double h=0.3;//����
	long double epsln=1.0e-2;//��������
	long double xmax=0;
	long double xmin=0;
	long double ymax=0;
	long double ymin=0;
	int warmn=200;
	int n=0;
	long double err=0;
	long double preerr=0;
	long double errtry=0;
	long double alpha=1.0;


	long double** sol=(long double**)calloc(tsize,sizeof(long double*));
	for (i=0;i<tsize;i++)
		sol[i]=(long double*)calloc(DIM,sizeof(long double));
	sol[0][0]=0;//��ʼʱ��
	sol[0][1]=0;//��ʼx
	sol[0][2]=0;//��ʼy
	sol[0][3]=0;//��ʼvx
	sol[0][4]=0;//��ʼvy

	trypara(sol,&err,warmn,epsln,&h,&xmax,&xmin,&ymax,&ymin);
	for(alpha=1;1;)
	{
			OMEGA+=alpha;
			trypara(sol,&errtry,warmn,epsln,&h,&xmax,&xmin,&ymax,&ymin);
			if(errtry>err)
			{	
				OMEGA-=2*alpha;
				trypara(sol,&errtry,warmn,epsln,&h,&xmax,&xmin,&ymax,&ymin);
				if(errtry<err)
					err=errtry;
				else
					OMEGA+=alpha;
			}
			else
				err=errtry;

			AX+=alpha;
			trypara(sol,&errtry,warmn,epsln,&h,&xmax,&xmin,&ymax,&ymin);
			if(errtry>err)
			{
				AX-=2*alpha;
				trypara(sol,&errtry,warmn,epsln,&h,&xmax,&xmin,&ymax,&ymin);
				if(errtry<err)
					err=errtry;
				else
					AX+=alpha;
			}
			else
				err=errtry;

			AY+=alpha;
			trypara(sol,&errtry,warmn,epsln,&h,&xmax,&xmin,&ymax,&ymin);
			if(errtry>err)
			{
				AY-=2*alpha;
				trypara(sol,&errtry,warmn,epsln,&h,&xmax,&xmin,&ymax,&ymin);
				if(errtry<err)
					err=errtry;
				else
					AY+=alpha;
			}
			else
				err=errtry;

			T0+=alpha;
			trypara(sol,&errtry,warmn,epsln,&h,&xmax,&xmin,&ymax,&ymin);
			if(errtry>err)
			{
				T0-=2*alpha;
				trypara(sol,&errtry,warmn,epsln,&h,&xmax,&xmin,&ymax,&ymin);
				if(errtry<err)
					err=errtry;
				else
					T0+=alpha;
			}
			else
				err=errtry;
			
			T2+=alpha;
			trypara(sol,&errtry,warmn,epsln,&h,&xmax,&xmin,&ymax,&ymin);
			if(errtry>err)
			{
				T2-=2*alpha;
				trypara(sol,&errtry,warmn,epsln,&h,&xmax,&xmin,&ymax,&ymin);
				if(errtry<err)
					err=errtry;
				else
					T2+=alpha;
			}
			else
				err=errtry;

			T1+=alpha;
			trypara(sol,&errtry,warmn,epsln,&h,&xmax,&xmin,&ymax,&ymin);
			if(errtry>err)
			{
				T1-=2*alpha;
				trypara(sol,&errtry,warmn,epsln,&h,&xmax,&xmin,&ymax,&ymin);
				if(errtry<err)
					err=errtry;
				else
					T1+=alpha;
			}
			else
				err=errtry;

			
			printf("{OMEGA,AX,AY,T0,T1,T2,alpha,error}={%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf}\n",OMEGA,AX,AY,T0,T1,T2,alpha,err);
			if(preerr==err)
				alpha/=5;
			else if(abs(preerr-err)<1.0e-3)
				alpha*=5;
			preerr=err;
			if(err<0.001)
				break;
	}//ȷ������
	trypara(sol,&err,2*warmn,epsln,&h,&xmax,&xmin,&ymax,&ymin);
	printf("{");
	for(i=0;i<2*warmn;i++)
		printf("{%lf,%lf},",sol[i][1],sol[i][2]);
	printf("\b};\n");
	printf("%lf,%lf,%lf,%lf",xmax,xmin,ymax,ymin);


	for(i=0;i<tsize;i++)
		free(sol[i]);
	free(sol);
	system("pause");
	return 0;
}
void diff(long double* diffvec,long double* vec)
{
	diffvec[1]=vec[3];
	diffvec[2]=vec[4];
	diffvec[3]=AX*exp(-pow(vec[0]/T1,(long double)2.0))+OMEGA*tanh(vec[0]/T0)*vec[4];
	diffvec[4]=AY*exp(-pow(vec[0]/T2,(long double)2.0))-OMEGA*tanh(vec[0]/T0)*vec[3];
}
void stRK(long double* nextvec, long double* vec,int dim,long double h)
{
	extern void diff(long double* diffvec,long double* vec);
	int i;
	long double** k=(long double**)calloc(4,sizeof(long double*));
	for(i=0;i<4;i++)
		k[i]=(long double*)calloc(dim,sizeof(long double));
	long double* p=(long double*)calloc(dim,sizeof(long double));

	for(i=0;i<4;i++)
		k[i][0]=1;
	diff(k[0],vec);
	for(i=0;i<dim;i++)
		p[i]=vec[i]+h*k[0][i]/2.0;
	diff(k[1],p);
	for(i=0;i<dim;i++)
		p[i]=vec[i]+h*k[1][i]/2.0;
	diff(k[2],p);
	for(i=0;i<dim;i++)
		p[i]=vec[i]+h*k[2][i];
	diff(k[3],p);	
	for(i=0;i<dim;i++)
		nextvec[i]=vec[i]+h*(k[0][i]+2*k[1][i]+2*k[2][i]+k[3][i])/6;

	for(i=0;i<4;i++)
		free(k[i]);
	free(k);
	free(p);
}
void varRK(long double* nextsol,long double* sol,int dim,long double* ph,long double epsln)
{
	extern void stRK(long double* nextvec, long double* vec,int dim,long double h);

	long double* ntsolhf1=(long double*)calloc(dim,sizeof(long double));
	long double* ntsolhf2=(long double*)calloc(dim,sizeof(long double));
	long double* ntsol=(long double*)calloc(dim,sizeof(long double));
	long double delta;
	int j;

	stRK(ntsol,sol,DIM,*ph);
	stRK(ntsolhf1,sol,DIM,*ph/2.0);
	stRK(ntsolhf2,ntsolhf1,DIM,*ph/2.0);
	delta=0;
	for(j=1;j<dim;j++)
		delta+=fabs(ntsolhf2[j]-ntsol[j]);
	if(delta<epsln)
	{
		do
		{
			*ph*=2.0;
			for(j=0;j<dim;j++)
			{
				nextsol[j]=ntsolhf1[j];
				ntsolhf1[j]=ntsol[j];
			}
			stRK(ntsol,sol,DIM,*ph);
			stRK(ntsolhf2,ntsolhf1,DIM,*ph/2.0);
			delta=0;
			for(j=1;j<dim;j++)
				delta+=fabs(ntsolhf2[j]-ntsol[j]);
		}
		while(delta<epsln);
		*ph/=2.0;
	}
	else
	{
		do
		{
			*ph/=2.0;
			for(j=0;j<dim;j++)
				ntsol[j]=ntsolhf1[j];
			stRK(ntsolhf1,sol,DIM,*ph/2.0);
			stRK(ntsolhf2,ntsolhf1,DIM,*ph/2.0);
			delta=0;
			for(j=1;j<dim;j++)
				delta+=fabs(ntsolhf2[j]-ntsol[j]);
		}
		while(delta>epsln);
		for(j=0;j<dim;j++)
			nextsol[j]=ntsolhf1[j];
	}
	free(ntsolhf1);
	free(ntsolhf2);
	free(ntsol);
}
long double rangeerr(long double xmax,long double xmin,long double ymax,long double ymin)
{
	return pow(xmax-20,2)+pow(xmin,2)+pow(ymax-4,2)+pow(ymin+16,2);
}
void trypara(long double** sol,long double* perror1,int warmn,long double epsln,long double* ph,long double* pxmax,long double* pxmin,long double* pymax,long double* pymin)
{
	int i;
	for(i=1;i<warmn;i++)
		varRK(sol[i],sol[i-1],DIM,ph,epsln);
	*pxmax=*pxmin=sol[warmn-1][1];
	*pymax=*pymin=sol[warmn-1][2];
	for(i=warmn;i<2*warmn;i++)
	{
		varRK(sol[i],sol[i-1],DIM,ph,epsln);
		if(sol[i][1]>*pxmax)
			*pxmax=sol[i][1];
		else if(sol[i][1]<*pxmin)
			*pxmin=sol[i][1];
		if(sol[i][2]>*pymax)
			*pymax=sol[i][2];
		else if(sol[i][2]<*pymin)
			*pymin=sol[i][2];
	}
	*perror1=rangeerr(*pxmax,*pxmin,*pymax,*pymin);
}
