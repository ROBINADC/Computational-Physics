#include "mpi.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include <ctime>

#define DIM 5


long double OMEGA=1;//ȫ�ֲ���

void diff(long double* diffvec,long double* vec);//΢�ַ�����
void stRK(long double* nextvec, long double* vec,int dim,long double h);//�Ľ�RK��
void varRK(long double* nextsol,long double* sol,int dim,long double* ph,long double epsln);//�䲽���Ľ�RK��
int main(int argc, char *argv[])
{
	int i,j;
	long tsize=10000;//ʱ���������
	long double h=0.3;//��ʼ����
	long double epsln=1.0e-6;//��������
	long double error=0.0;//�������

	long double** sol=(long double**)calloc(tsize,sizeof(long double*));
	for (i=0;i<tsize;i++)
		sol[i]=(long double*)calloc(DIM,sizeof(long double));
	sol[0][0]=0;//��ʼʱ��
	sol[0][1]=0;//��ʼx
	sol[0][2]=0;//��ʼy
	sol[0][3]=0;//��ʼvx
	sol[0][4]=0.2;//��ʼvy

	printf("xydata={");
	printf("{%lf,%lf},",sol[0][1],sol[0][2]);
	for(i=1;i<100;i++)
	{
		varRK(sol[i],sol[i-1],DIM,&h,epsln);
		printf("{%lf,%lf},",sol[i][1],sol[i][2]);
	}
	printf("\b};\n");//��켣


	//printf("herrdata={");
	//for(i=1,epsln=1e-4;i<30;i++)
	//{
	//	varRK(sol[1],sol[0],DIM,&h,epsln);
	//	printf("{%lf,%lf},",h,fabs(sol[1][1]-0.2*(1.0-cos(sol[1][0])))+fabs(sol[1][2]-0.2*sin(sol[1][0])));
	//	epsln*=2;
	//}
	//printf("\b};\n");//������



	for(i=0;i<tsize;i++)
		free(sol[i]);
	free(sol);
	system("pause");
	return 0;

}
void diff(long double* diffvec,long double* vec)
{
	diffvec[1]=vec[3];
	diffvec[2]=vec[4];
	diffvec[3]=OMEGA*vec[4];
	diffvec[4]=-OMEGA*vec[3];
}
void stRK(long double* nextvec, long double* vec,int dim,long double h)
{
	extern void diff(long double* diffvec,long double* vec);
	int i;
	long double** k=(long double**)calloc(4,sizeof(long double*));
	for(i=0;i<4;i++)
		k[i]=(long double*)calloc(dim,sizeof(long double));
	long double* p=(long double*)calloc(dim,sizeof(long double));

	for(i=0;i<4;i++)
		k[i][0]=1;
	diff(k[0],vec);
	for(i=0;i<dim;i++)
		p[i]=vec[i]+h*k[0][i]/2.0;
	diff(k[1],p);
	for(i=0;i<dim;i++)
		p[i]=vec[i]+h*k[1][i]/2.0;
	diff(k[2],p);
	for(i=0;i<dim;i++)
		p[i]=vec[i]+h*k[2][i];
	diff(k[3],p);	
	for(i=0;i<dim;i++)
		nextvec[i]=vec[i]+h*(k[0][i]+2*k[1][i]+2*k[2][i]+k[3][i])/6;

	for(i=0;i<4;i++)
		free(k[i]);
	free(k);
	free(p);
}
void varRK(long double* nextsol,long double* sol,int dim,long double* ph,long double epsln)
{
	extern void stRK(long double* nextvec, long double* vec,int dim,long double h);

	long double* ntsolhf1=(long double*)calloc(dim,sizeof(long double));
	long double* ntsolhf2=(long double*)calloc(dim,sizeof(long double));
	long double* ntsol=(long double*)calloc(dim,sizeof(long double));
	long double delta;
	int j;

	stRK(ntsol,sol,DIM,*ph);
	stRK(ntsolhf1,sol,DIM,*ph/2.0);
	stRK(ntsolhf2,ntsolhf1,DIM,*ph/2.0);
	delta=0;
	for(j=1;j<dim;j++)
		delta+=fabs(ntsolhf2[j]-ntsol[j]);
	if(delta<epsln)
	{
		do
		{
			*ph*=2.0;
			for(j=0;j<dim;j++)
			{
				nextsol[j]=ntsolhf1[j];
				ntsolhf1[j]=ntsol[j];
			}
			stRK(ntsol,sol,DIM,*ph);
			stRK(ntsolhf2,ntsolhf1,DIM,*ph/2.0);
			delta=0;
			for(j=1;j<dim;j++)
				delta+=fabs(ntsolhf2[j]-ntsol[j]);
		}
		while(delta<epsln);
		*ph/=2.0;
	}
	else
	{
		do
		{
			*ph/=2.0;
			for(j=0;j<dim;j++)
				ntsol[j]=ntsolhf1[j];
			stRK(ntsolhf1,sol,DIM,*ph/2.0);
			stRK(ntsolhf2,ntsolhf1,DIM,*ph/2.0);
			delta=0;
			for(j=1;j<dim;j++)
				delta+=fabs(ntsolhf2[j]-ntsol[j]);
		}
		while(delta>epsln);
		for(j=0;j<dim;j++)
			nextsol[j]=ntsolhf1[j];
	}
	free(ntsolhf1);
	free(ntsolhf2);
	free(ntsol);
}
